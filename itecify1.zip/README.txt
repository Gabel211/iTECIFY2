# iTECify redesign pack

Nu am putut modifica direct arhiva `.rar` în acest mediu, dar ți-am pregătit un pachet drop-in care păstrează structura și schimbă doar designul.

## Fișiere incluse
- `login_styles.css`
- `signup_style.css`
- `editor_styles.css`
- `itecify-logo.svg`
- `logo-snippets.txt`

## Cum le pui
1. Înlocuiești fișierele CSS existente cu cele din acest pachet.
2. Dacă vrei să apară logo-ul text în pagini, adaugă unul din snippet-urile din `logo-snippets.txt` în header-ul fiecărei pagini.
3. Dacă ai deja un container/header existent, doar inserezi:
   `<div class="logo">iTECify</div>`

CSS-ul este făcut să nu-ți schimbe structura, doar aspectul: culori, carduri, butoane, inputuri, editor, tabele și header.
